package com.example.demo.core.ports.in;

public interface GenerateEliminationFixturePort {
    void generate(Long tournamentId);
}
