package com.example.demo.core.domain.models;

public class Admin {

}
