package com.example.demo.core.ports.in;

public interface RegisterToTournamentPort {
    void register(Long tournamentId, Long userId);
}
