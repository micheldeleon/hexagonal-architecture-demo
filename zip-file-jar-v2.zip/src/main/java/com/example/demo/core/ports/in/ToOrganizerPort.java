package com.example.demo.core.ports.in;

public interface ToOrganizerPort {
public void toOrganizer(Long userId);
}
