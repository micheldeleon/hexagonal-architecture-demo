package com.example.demo.core.domain.models.Formats;

import com.example.demo.core.domain.models.Format;

public class RaceFormat extends Format {

}
