package com.example.demo.adapters.in.api.dto;

public record TeamSummaryDto(
    Long id,
    String name
) {
}
