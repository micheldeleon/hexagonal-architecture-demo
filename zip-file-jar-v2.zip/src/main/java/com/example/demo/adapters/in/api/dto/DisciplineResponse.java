package com.example.demo.adapters.in.api.dto;

public record DisciplineResponse(Long id, String name, boolean collective) {
}
