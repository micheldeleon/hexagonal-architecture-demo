package com.example.demo.adapters.in.api.dto;

public record RunnerRegistrationRequest(
        String fullName,
        String nationalId) {
}
