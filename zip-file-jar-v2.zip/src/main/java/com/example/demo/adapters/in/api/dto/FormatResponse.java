package com.example.demo.adapters.in.api.dto;

public record FormatResponse(Long id, String name, boolean generaFixture) {
}
